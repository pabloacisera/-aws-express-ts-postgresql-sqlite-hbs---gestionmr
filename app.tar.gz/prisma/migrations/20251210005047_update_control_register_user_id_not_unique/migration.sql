-- DropIndex
DROP INDEX "ControlRegister_userId_key";
