-- AlterTable
ALTER TABLE "UserConfig" ALTER COLUMN "pdfGenerate" SET DEFAULT true,
ALTER COLUMN "cacheRegistries" SET DEFAULT false;
