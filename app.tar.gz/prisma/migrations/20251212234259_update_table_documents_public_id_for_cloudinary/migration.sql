-- AlterTable
ALTER TABLE "CertificateDocument" ADD COLUMN     "publicId" VARCHAR(255);
